/*		 
 * Sux: Succinct data structures
 *
 * Copyright (C) 2007-2011 Sebastiano Vigna 
 *
 *  This library is free software; you can redistribute it and/or modify it
 *  under the terms of the GNU Lesser General Public License as published by the Free
 *  Software Foundation; either version 3 of the License, or (at your option)
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 *  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 *  for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 */

#include <cstdio>
#include <ctime>
#include <cassert>
#include <cstdlib>
#include <climits>
#include <stdint.h>
#include <sys/time.h>
#include <sys/resource.h>

const int REPEATS = 100 * 1000 * 1000;

#define ONES_STEP_4 ( 0x1111111111111111ULL )
#define ONES_STEP_8 ( 0x0101010101010101ULL )
#define INCR_STEP_8 ( 0x80ULL << 56 | 0x40ULL << 48 | 0x20ULL << 40 | 0x10ULL << 32 | 0x8ULL << 24 | 0x4ULL << 16 | 0x2ULL << 8 | 0x1 )
#define MSBS_STEP_8 ( 0x80ULL * ONES_STEP_8 )

#define LEQ_STEP_8(x,y) ( ( ( ( ( (y) | MSBS_STEP_8 ) - ( (x) & ~MSBS_STEP_8 ) ) ^ (x) ^ (y) ) & MSBS_STEP_8 ) >> 7 )
#define ZCOMPARE_STEP_8(x) ( ( ( x | ( ( x | MSBS_STEP_8 ) - ONES_STEP_8 ) ) & MSBS_STEP_8 ) >> 7 )

const unsigned char popcount[] = {
0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4,1,2,2,3,2,3,3,4,2,3,3,4,3,4,4,5,
1,2,2,3,2,3,3,4,2,3,3,4,3,4,4,5,2,3,3,4,3,4,4,5,3,4,4,5,4,5,5,6,
1,2,2,3,2,3,3,4,2,3,3,4,3,4,4,5,2,3,3,4,3,4,4,5,3,4,4,5,4,5,5,6,
2,3,3,4,3,4,4,5,3,4,4,5,4,5,5,6,3,4,4,5,4,5,5,6,4,5,5,6,5,6,6,7,
1,2,2,3,2,3,3,4,2,3,3,4,3,4,4,5,2,3,3,4,3,4,4,5,3,4,4,5,4,5,5,6,
2,3,3,4,3,4,4,5,3,4,4,5,4,5,5,6,3,4,4,5,4,5,5,6,4,5,5,6,5,6,6,7,
2,3,3,4,3,4,4,5,3,4,4,5,4,5,5,6,3,4,4,5,4,5,5,6,4,5,5,6,5,6,6,7,
3,4,4,5,4,5,5,6,4,5,5,6,5,6,6,7,4,5,5,6,5,6,6,7,5,6,6,7,6,7,7,8,
};

long long getusertime() {
	struct rusage rusage;
	getrusage( 0, &rusage );
	return rusage.ru_utime.tv_sec * 1000000L + rusage.ru_utime.tv_usec;
}

/* Selects the k-th (k>=0) bit in l. Returns 72 if no such bit exists. */

__inline int select_in_word( const uint64_t x, const int k ) {
	// Phase 1: sums by byte
	register uint64_t byte_sums = x - ( ( x & 0xa * ONES_STEP_4 ) >> 1 );
	byte_sums = ( byte_sums & 3 * ONES_STEP_4 ) + ( ( byte_sums >> 2 ) & 3 * ONES_STEP_4 );
	byte_sums = ( byte_sums + ( byte_sums >> 4 ) ) & 0x0f * ONES_STEP_8;
	byte_sums *= ONES_STEP_8;

	// Phase 2: compare each byte sum with k
	const uint64_t k_step_8 = k * ONES_STEP_8;
	const uint64_t place = ( LEQ_STEP_8( byte_sums, k_step_8 ) * ONES_STEP_8 >> 53 ) & ~0x7;

	// Phase 3: Locate the relevant byte and make 8 copies with incremental masks
	const int byte_rank = k - ( ( ( byte_sums << 8 ) >> place ) & 0xFF );
	const uint64_t z = ( x >> place & 0xFF ) * ONES_STEP_8 & INCR_STEP_8;

	const uint64_t spread_bits = ( x >> place & 0xFF ) * ONES_STEP_8 & INCR_STEP_8;
	const uint64_t bit_sums = ZCOMPARE_STEP_8( spread_bits ) * ONES_STEP_8;

	// Compute the inside-byte location and return the sum
	const uint64_t byte_rank_step_8 = byte_rank * ONES_STEP_8;
	return place + ( LEQ_STEP_8( bit_sums, byte_rank_step_8 ) * ONES_STEP_8 >> 56 );
}


__inline int select_in_word_popcount( const uint64_t x, const int k ) {
	for( int i = 0, c = k; i < 64; i+=8 )
		if ( ( c -= popcount[ x >> i & 0xFF ] ) < 0 ) {
			c += popcount[ x >> i & 0xFF ];
			for( int j = 0; j < 8; j++ ) if ( ( x & 1ULL << ( i + j ) ) && c-- == 0 ) return i + j;
		}
	return -1;
}

int main( int argc, char *argv[] ) {
	assert( sizeof(int) == 4 );
	assert( sizeof(long long) == 8 );

	long long start, elapsed;
	double s;
	int64_t w = 0xA0A0A0A0A0A0A0A0ULL;
	uint64_t dummy = 0xF0F0F0F0F0F0F0F0ULL; // Just to keep the compiler from excising code.
	start = getusertime();

	for( int k = REPEATS / 10; k-- != 0; ) {
		dummy ^= select_in_word( dummy, 0 );
		dummy ^= select_in_word( dummy, 3 );
		dummy ^= select_in_word( dummy, 6 );
		dummy ^= select_in_word( dummy, 9 );
		dummy ^= select_in_word( dummy, 12 );
		dummy ^= select_in_word( dummy, 15 );
		dummy ^= select_in_word( dummy, 18 );
		dummy ^= select_in_word( dummy, 21 );
		dummy ^= select_in_word( dummy, 24 );
		dummy ^= select_in_word( dummy, 27 );
	}

	elapsed = getusertime() - start;
	s = elapsed / 1E6;
	printf( "%f s, %f selects/s, %f ns/select [broadword]\n", s, REPEATS / s, 1E9 * s / REPEATS );

	w = 0xF0F0F0F0F0F0F0F0ULL;
	start = getusertime();

	for( int k = REPEATS / 10; k-- != 0; ) {
		dummy ^= select_in_word_popcount( w, 0 );
		dummy ^= select_in_word_popcount( w, 3 );
		dummy ^= select_in_word_popcount( w, 6 );
		dummy ^= select_in_word_popcount( w, 9 );
		dummy ^= select_in_word_popcount( w, 12 );
		dummy ^= select_in_word_popcount( w, 15 );
		dummy ^= select_in_word_popcount( w, 18 );
		dummy ^= select_in_word_popcount( w, 21 );
		dummy ^= select_in_word_popcount( w, 24 );
		dummy ^= select_in_word_popcount( w, 27 );
	}

	elapsed = getusertime() - start;
	s = elapsed / 1E6;
	printf( "%f s, %f selects/s, %f ns/select [popcount]\n", s, REPEATS / s, 1E9 * s / REPEATS );

	w = 0xF000F000F000F000ULL;
	start = getusertime();

	for( int k = REPEATS / 10; k-- != 0; ) {
		dummy ^= select_in_word_popcount( w, 0 );
		dummy ^= select_in_word_popcount( w, 3 );
		dummy ^= select_in_word_popcount( w, 6 );
		dummy ^= select_in_word_popcount( w, 9 );
		dummy ^= select_in_word_popcount( w, 12 );
		dummy ^= select_in_word_popcount( w, 0 );
		dummy ^= select_in_word_popcount( w, 3 );
		dummy ^= select_in_word_popcount( w, 6 );
		dummy ^= select_in_word_popcount( w, 9 );
		dummy ^= select_in_word_popcount( w, 12 );
	}

	elapsed = getusertime() - start;
	s = elapsed / 1E6;
	printf( "%f s, %f selects/s, %f ns/select [popcount, low density]\n", s, REPEATS / s, 1E9 * s / REPEATS );

	w = 0xF0000000F0000000ULL;
	start = getusertime();

	for( int k = REPEATS / 10; k-- != 0; ) {
		dummy ^= select_in_word_popcount( w, 0 );
		dummy ^= select_in_word_popcount( w, 3 );
		dummy ^= select_in_word_popcount( w, 6 );
		dummy ^= select_in_word_popcount( w, 0 );
		dummy ^= select_in_word_popcount( w, 3 );
		dummy ^= select_in_word_popcount( w, 6 );
		dummy ^= select_in_word_popcount( w, 0 );
		dummy ^= select_in_word_popcount( w, 3 );
		dummy ^= select_in_word_popcount( w, 6 );
		dummy ^= select_in_word_popcount( w, 0 );
	}

	elapsed = getusertime() - start;
	s = elapsed / 1E6;
	printf( "%f s, %f selects/s, %f ns/select [popcount, very low density]\n", s, REPEATS / s, 1E9 * s / REPEATS );

	w = 0xF000000000000000ULL;
	start = getusertime();

	for( int k = REPEATS / 10; k-- != 0; ) {
		dummy ^= select_in_word_popcount( w, 0 );
		dummy ^= select_in_word_popcount( w, 3 );
		dummy ^= select_in_word_popcount( w, 0 );
		dummy ^= select_in_word_popcount( w, 3 );
		dummy ^= select_in_word_popcount( w, 0 );
		dummy ^= select_in_word_popcount( w, 3 );
		dummy ^= select_in_word_popcount( w, 0 );
		dummy ^= select_in_word_popcount( w, 3 );
		dummy ^= select_in_word_popcount( w, 0 );
		dummy ^= select_in_word_popcount( w, 3 );
	}

	elapsed = getusertime() - start;
	s = elapsed / 1E6;
	printf( "%f s, %f selects/s, %f ns/select [popcount, lowest density]\n", s, REPEATS / s, 1E9 * s / REPEATS );
	if ( dummy == 42 ) printf( "42" ); // To avoid excision

	return 0;
}
