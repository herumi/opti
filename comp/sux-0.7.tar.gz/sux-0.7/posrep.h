const int POSITIONS = 1000000;
const int REPEATS = 10;
