/*		 
 * Sux: Succinct data structures
 *
 * Copyright (C) 2007-2011 Sebastiano Vigna 
 *
 *  This library is free software; you can redistribute it and/or modify it
 *  under the terms of the GNU Lesser General Public License as published by the Free
 *  Software Foundation; either version 3 of the License, or (at your option)
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 *  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 *  for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 */

using namespace std;

#define __STDC_LIMIT_MACROS 1
#include <stdint.h>
#include <stdio.h>
#include <time.h>
#include <assert.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/resource.h>
#include "elias_fano.h"
#include "posrep.h"

static uint32_t rnd_curr = 1;

__inline uint32_t rnd() {
	return rnd_curr = ( 279470273ULL * rnd_curr ) % 4294967291ULL;
}

uint64_t getusertime() {
	struct rusage rusage;
	getrusage( 0, &rusage );
	return rusage.ru_utime.tv_sec * 1000000ULL + rusage.ru_utime.tv_usec;
}

int main( int argc, char *argv[] ) {
	assert( argc >= 3 );
	assert( sizeof(int) == 4 );
	assert( sizeof(long long) == 8 );

	if ( argc < 3 ) {
		fprintf( stderr, "Usage: %s NUMBITS DENSITY0 [DENSITY1]\n", argv[ 0 ] );
		return 0;
	}

	const long long num_bits = strtoll( argv[ 1 ], NULL, 0 );
	printf( "Number of bits: %lld\n", num_bits );
	printf( "Number of words: %lld\n", num_bits / 64 );
	printf( "Number of blocks: %lld\n", ( num_bits / 64 ) / 16 );
	uint64_t * const bits = (uint64_t *)calloc( num_bits / 64 + 1, sizeof *bits );

	double density0 = atof( argv[ 2 ] ), density1 = argc > 3 ? atof( argv[ 3 ] ) : density0;
	assert( density0 >= 0 );
	assert( density0 <= 1 );
	assert( density1 >= 0 );
	assert( density1 <= 1 );

	// Init array with given density
	const uint32_t threshold0 = (uint32_t)((UINT32_MAX) * density0), threshold1 = (uint32_t)((UINT32_MAX) * density1);

	uint64_t num_ones_first_half = 0, num_ones_second_half = 0;

	for( long long i = 0; i < num_bits / 2; i++ ) if ( rnd() < threshold0 ) { num_ones_first_half++; bits[ i / 64 ] |= 1LL << i % 64; }
	for( long long i = num_bits / 2; i < num_bits; i++ ) if ( rnd() < threshold1 ) { num_ones_second_half++; bits[ i / 64 ] |= 1LL << i % 64; }

#ifdef DEBUG
	printf("First words: %016llx %016llx %016llx %016llx\n", bits[ 0 ], bits[ 1 ], bits[ 2 ], bits[ 3 ] );
#endif

	elias_fano rs( bits, num_bits );

	long long dummy = 0x12345678; // Just to keep the compiler from excising code.

	// Cache a few millions random positions
	uint64_t * const position = (uint64_t *)calloc( POSITIONS, sizeof *position );
	assert( num_bits != 0 );
	for( int i = POSITIONS; i-- != 0; ) position[ i ] = ( ( (uint64_t)rnd() << 32 | rnd() ) & 0x7FFFFFFFFFFFFFFFLL ) % num_bits;

	long long start, elapsed;
	double s;

	printf( "Bit cost: %lld (%.2f%%)\n", rs.bit_count(), (rs.bit_count()*100.0)/num_bits);

#ifndef NORANKTEST

	start = getusertime();

	for( int k = REPEATS; k-- != 0; )
		for( int i = 0; i < POSITIONS; i += 10 ) {
			dummy ^= rs.rank( position[ i ] );
			dummy ^= rs.rank( position[ i + 1 ] );
			dummy ^= rs.rank( position[ i + 2 ] );
			dummy ^= rs.rank( position[ i + 3 ] );
			dummy ^= rs.rank( position[ i + 4 ] );
			dummy ^= rs.rank( position[ i + 5 ] );
			dummy ^= rs.rank( position[ i + 6 ] );
			dummy ^= rs.rank( position[ i + 7 ] );
			dummy ^= rs.rank( position[ i + 8 ] );
			dummy ^= rs.rank( position[ i + 9 ] );
		}

	elapsed = getusertime() - start;
	s = elapsed / 1E6;
	printf( "%f s, %f ranks/s, %f ns/rank\n", s, (REPEATS * POSITIONS) / s, 1E9 * s / (REPEATS * POSITIONS) );
#endif

	if ( num_ones_first_half && num_ones_second_half  ) {
		for( long long i = POSITIONS; i-- != POSITIONS / 2; ) position[ i ] = ( ( (uint64_t)rnd() << 32 | rnd() ) & 0x7FFFFFFFFFFFFFFFLL ) % num_ones_first_half;
		for( long long i = POSITIONS / 2; i-- != 0; ) position[ i ] = num_ones_first_half + ( ( (uint64_t)rnd() << 32 | rnd() ) & 0x7FFFFFFFFFFFFFFFLL ) % num_ones_second_half;

		start = getusertime();

		for( int k = REPEATS; k-- != 0; )
			for( int i = 0; i < POSITIONS; i += 10 ) {
				dummy ^= rs.select( position[ i ] );
				dummy ^= rs.select( position[ i + 1 ] );
				dummy ^= rs.select( position[ i + 2 ] );
				dummy ^= rs.select( position[ i + 3 ] );
				dummy ^= rs.select( position[ i + 4 ] );
				dummy ^= rs.select( position[ i + 5 ] );
				dummy ^= rs.select( position[ i + 6 ] );
				dummy ^= rs.select( position[ i + 7 ] );
				dummy ^= rs.select( position[ i + 8 ] );
				dummy ^= rs.select( position[ i + 9 ] );
			}

		elapsed = getusertime() - start;
		s = elapsed / 1E6;
		printf( "%f s, %f selects/s, %f ns/select\n", s, (REPEATS * POSITIONS) / s, 1E9 * s / (REPEATS * POSITIONS) );
	}
	else printf( "Too few ones to measure select speed\n" );

#ifdef COUNTS
	rs.print_counts();
#endif
	if ( dummy == 42 ) printf( "42" ); // To avoid excision

	return 0;
}
