/** \defgroup int_vector int_vector */

#include "int_vector.hpp"
#include "enc_vector.hpp"
#include "enc_vector_theo.hpp"
#include "enc_vector_dna.hpp"
