/*! This header includes typedefs and header to make the code
 *  compatible to various programming tools.
 */

// Things for Microsoft Visual C++
#include <ciso646>  // this enables the use of logical operators ,,and'', ,,or'', ,,not''
